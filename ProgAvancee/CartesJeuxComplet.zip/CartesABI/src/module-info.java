module cartes {
	requires java.desktop;
	exports cartes;
}